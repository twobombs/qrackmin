# qimcifa
Quantum-inspired Monte Carlo integer factoring algorithm
